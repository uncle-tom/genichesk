<div class="menu-verhnee-menyu-container">
			    		<ul id="menu-verhnee-menyu" class="menu">
			    			<li>
			    				<a href="/">Главная</a>
			    			</li>
			    			<li class="dropdown">
			    				<p class="dropdown-toggle" >Услуги</p>
			    				<div class="dropdown-menu-125 dropdown-menu">
			    					<?php wp_nav_menu( array(
											'theme_location'  => '',
											'menu'            => '6', 
											'container'       => 'div', 
											'container_class' => '', 
											'container_id'    => '',
											'menu_class'      => 'menu', 
											'menu_id'         => '',
											'echo'            => true,
											'fallback_cb'     => 'wp_page_menu',
											'before'          => '',
											'after'           => '',
											'link_before'     => '',
											'link_after'      => '',
											'items_wrap'      => '<ul id="%1$s" class="%2$s">%3$s</ul>',
											'depth'           => 0,
											'walker'          => '',
										) ); ?>
			    				</div>
			    			</li>
			    			<li>
			    				<li class="dropdown">
			    				<p class="dropdown-toggle" data-toggle="dropdown">О компании</p>
			    				<div class="dropdown-menu-125 dropdown-menu">
			    					<?php wp_nav_menu( array(
											'theme_location'  => '',
											'menu'            => '7', 
											'container'       => 'div', 
											'container_class' => '', 
											'container_id'    => '',
											'menu_class'      => 'menu', 
											'menu_id'         => '',
											'echo'            => true,
											'fallback_cb'     => 'wp_page_menu',
											'before'          => '',
											'after'           => '',
											'link_before'     => '',
											'link_after'      => '',
											'items_wrap'      => '<ul id="%1$s" class="%2$s">%3$s</ul>',
											'depth'           => 0,
											'walker'          => '',
										) ); ?>
			    				</div>
			    			</li>
			    			</li>
			    			<li>
			    				<a href="http://defy-logistics.com.ua/novosti/">Новости</a>
			    			</li>
			    			<li>
			    				<a href="http://defy-logistics.com.ua/kontaktyi/">Контакты</a>
			    			</li>
			    		</ul>
			    	</div>