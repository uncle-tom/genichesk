<footer class="text-center">
	<a href="/" >Genichesk info</a>
</footer>

<!-- Material -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.8/js/materialize.min.js"></script>

<script>
$(".hamburger-menu").sideNav({
 menuWidth: 250,
 edge: 'right',
});
</script>
